﻿#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;

const int _INF = 100000;

struct tDatos {
	vector <int> sol;
	vector <bool>marca;
	int suma;
};

// función que resuelve el problema
int resolver(vector <vector<int>> const& tabla, tDatos &d, int k, int f, vector <int> const& acum, int &solMejor) {
	for (int i = 0; i < f; i++) {
		d.sol[k] = i;
		d.suma += tabla[k][i];
		if (!d.marca[i]) {
			d.marca[i] = true;
			if (k == d.sol.size() - 1) {
				if (solMejor > d.suma) solMejor = d.suma;
			}//
			else {
				solMejor = resolver(tabla, d, k + 1, f, acum, solMejor);	
			}
			d.marca[i] = false;
		}
		d.suma -= tabla[k][i];
	}
	return solMejor;
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
	int func;
	tDatos d;
	// leer los datos de la entrada
	cin >> func;
	if (func == 0)return false;
	
	//matriz
	vector <vector<int>> tabla;
	for (int i = 0; i < func; ++i) {
		vector<int> aux(func);
		for (int j = 0; j < func; ++j) cin >> aux[j];
			tabla.push_back(aux);
	}

	d.marca.assign(func, false);
	d.sol.assign(func, 0);
	d.suma = 0;

	vector<int> acum(func);
	for (int i = 0; i < func; ++i) {
		int auxMax = _INF;
		for (int j = 0; j < func; ++j)
			if (auxMax > tabla[i][j]) auxMax = tabla[i][j];
		acum[i] = auxMax;
	}
	// Vector acumulados
	for (int i = (int)acum.size() - 1; i > 0; --i) {
		acum[i - 1] += acum[i];
	}

	int solMejor = _INF;

	int n = resolver(tabla, d, 0, func, acum, solMejor);
	cout << n << "\n";

	return true;
}

int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("sample-25.1.in");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


	while (resuelveCaso());


	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif

	return 0;
}