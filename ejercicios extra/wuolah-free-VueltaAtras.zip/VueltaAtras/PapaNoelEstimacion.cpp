﻿#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;

// Para hacerlo sin estimacion hay que quitar el vector acum

const int _INF = -100000000;

struct tDatos {
	int juguetes;
	int ninos;
	vector<vector<int>>satis;
};

struct tSol {
	vector <int> sol;
	int sumaSatisfaccion;
};

// función que resuelve el problema
void resolver(tDatos const& d, int k, tSol s, vector<bool>& marcas, vector <int> const& acum, int &solMejor) {

	for (int i = 0; i < d.juguetes; i++) {
		s.sol[k] = i;
		s.sumaSatisfaccion += d.satis[k][i];
		if (!marcas[i]) {
			marcas[i] = true;
			if (k == s.sol.size() - 1) {
				if (solMejor < s.sumaSatisfaccion) solMejor = s.sumaSatisfaccion;
			}//lleno
			else {
				if (s.sumaSatisfaccion + acum[k + 1] > solMejor) {
					resolver(d, k + 1, s, marcas, acum, solMejor);
				}
			}//no lleno
			marcas[i] = false;
		}
		s.sumaSatisfaccion -= d.satis[k][i];
	}//for
	
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
	tDatos datos;
	tSol sol;

	// leer los datos de la entrada

	cin >> datos.juguetes;
	if (!cin)return false;
	cin >> datos.ninos;

	for (int i = 0; i < datos.ninos; ++i) {
		vector<int> aux(datos.juguetes);
		for (int j = 0; j < datos.juguetes; ++j) cin >> aux[j];
		datos.satis.push_back(aux);
	}

	//acum
	vector<int> acum(datos.ninos);
	for (int i = 0; i < datos.ninos; ++i) {
		int auxMax = _INF;
		for (int j = 0; j < datos.juguetes; ++j)
			if (auxMax < datos.satis[i][j]) auxMax = datos.satis[i][j];
		acum[i] = auxMax;
	}
	// Vector acumulados
	for (int i = (int)acum.size() - 1; i > 0; --i) {
		acum[i - 1] += acum[i];
	}

	// marcas
	sol.sol.assign(datos.ninos, 0);
	sol.sumaSatisfaccion = 0;
	vector<bool> marcas(datos.juguetes, false);
	int solMejor = _INF;

	resolver(datos, 0, sol, marcas, acum, solMejor);

	cout << solMejor << "\n";

	return true;
}

int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 

	while (resuelveCaso());

	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif

	return 0;
}