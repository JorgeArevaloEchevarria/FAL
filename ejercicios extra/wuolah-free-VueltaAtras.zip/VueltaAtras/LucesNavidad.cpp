#include <iostream>
#include <fstream>
#include <vector>
#include <stdio.h>
#include <utility>
#include <cstdlib>
using namespace std;

struct tDatos {
	int cont;
	int consumo;
};

struct tEntrada {
	int longitud;
	int numColores;
	int consumoMax;
};

bool Terminar(int consumoAct, int consumoMax) {
	return (consumoAct <= consumoMax);
}

bool esValido(int k, vector<int> const& sol, vector <int> sumaLuces, int lucesTotal) {
	// que no haya mas de dos colores iguales juntos
	if (k > 1 && sol[k] == sol[k - 1] && sol[k] == sol[k - 2]) return false;
	
	// que el numero de lucees mas una unidad supere al resto
	if (sumaLuces[sol[k]] > lucesTotal - sumaLuces[sol[k]] + 1) return false;
	//if (2 * sumaLuces[sol[k]] > lucesTotal + 1) return false;

	return true;
}

// Agrupar los datos en structs por datos de entrada, datos actuales, marcaje y solMejor
void resolver(int longi, int luces, vector<int> const& consumo, int consumoMax, int k, vector <int> &sol, int &consumoAct,
	vector <int> &sumaLuces, int &lucesTotal, int &cont) {
	for (int i = 0; i < luces; i++) {
		sol[k] = i;
		consumoAct += consumo[i];
		sumaLuces[i]++;
		lucesTotal++;
		if (esValido(k, sol, sumaLuces, lucesTotal)) {
			if (k == longi - 1) {
				if (Terminar(consumoAct, consumoMax)) {
					cont++;
				}
			}// lleno
			else {
				resolver(longi, luces, consumo, consumoMax, k + 1, sol, consumoAct, sumaLuces, lucesTotal, cont);
			}
		}// esValido
		sumaLuces[i]--;
		consumoAct -= consumo[i];
		lucesTotal--;
	}//for
}

bool resuelveCaso() {
	int longi, luces, consumoMax;
	cin >> longi;
	if (longi == 0) return false;
	cin >> luces >> consumoMax;
	
	vector<int> consumoLuces(luces);
	for (int & i : consumoLuces) std::cin >> i;

	vector <int> sol(longi);
	vector <int> contLuces(luces);
	// rellenamos el contador de luces a 0
	for (int i = 0; i < luces; i++) {
		contLuces[i] = 0;
	}

	int consumoAct = 0;
	int lucesTotal = 0;
	int cont = 0;
	resolver(longi, luces, consumoLuces, consumoMax, 0, sol, consumoAct, contLuces, lucesTotal, cont);

	cout << cont << "\n";

		return true;
}

int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

	while (resuelveCaso());

	// Para restablecer entrada. Comentar para acepta el reto

#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif

	return 0;
}
